//
//  SwiftDB-Bridging-Header.h
//  SwiftDB
//
//  Created by Dhruval Darji on 3/14/16.
//  Copyright © 2016 Dhruval Darji. All rights reserved.
//

#ifndef SwiftDB_Bridging_Header_h
#define SwiftDB_Bridging_Header_h


#import "FMDatabase.h"


#endif /* SwiftDB_Bridging_Header_h */
