//
//  StudentInfo.swift
//  SwiftDB
//
//  Created by Dhruval Darji on 3/14/16.
//  Copyright © 2016 Dhruval Darji. All rights reserved.
//

import UIKit

/** Our Student Model **/
class StudentInfo: NSObject {
    
    var Id: String = String()
    var Name: String = String()
    var Grade: String = String()
    
}